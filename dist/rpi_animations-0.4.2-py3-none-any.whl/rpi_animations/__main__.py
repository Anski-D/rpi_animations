from . import main

if __name__ == '__main__':
    # Run the main program
    main()
